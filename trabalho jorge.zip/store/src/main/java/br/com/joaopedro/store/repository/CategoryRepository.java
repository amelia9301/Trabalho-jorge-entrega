package br.com.joaopedro.store.repository;

import br.com.joaopedro.store.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}