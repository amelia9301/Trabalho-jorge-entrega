package br.com.joaopedro.store.repository;

import br.com.joaopedro.store.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}