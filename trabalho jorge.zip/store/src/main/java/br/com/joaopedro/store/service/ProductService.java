package br.com.joaopedro.store.service;

import br.com.joaopedro.store.model.Category;
import br.com.joaopedro.store.model.Product;
import br.com.joaopedro.store.repository.CategoryRepository;
import br.com.joaopedro.store.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public ProductService(ProductRepository productRepository, CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    public Product save(Product product) {
        return productRepository.save(product);
    }

    public List<Product> findAll() {
        return productRepository.findAll();
    }
}